<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
			<title>
				
			</title>
		<script></script>
		<style>
		
		</style>
	
	</head>
	<body>		
		<h1>Register Awal</h1>
		<a href="http://localhost:12/verify/<?php echo e($user->token); ?>/<?php echo e($user->id); ?>">Klik untuk mengaktifkan aku</a>
	</body>
</html>
